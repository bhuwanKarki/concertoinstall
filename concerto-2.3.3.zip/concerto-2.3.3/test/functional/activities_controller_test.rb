require 'test_helper'

class ActivitiesControllerTest < ActionController::TestCase

end
