require 'test_helper'

class Frontend::FieldsControllerTest < ActionController::TestCase
  include Devise::TestHelpers
  fixtures :screens, :fields
end
