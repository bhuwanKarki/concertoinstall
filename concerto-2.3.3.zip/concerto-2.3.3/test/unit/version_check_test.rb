require 'test_helper'

class VersionCheckTest < ActiveSupport::TestCase
  test 'should return nil' do
    assert true
  end
end
