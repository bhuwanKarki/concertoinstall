require 'test_helper'

class MediasHelperTest < ActionView::TestCase
end
