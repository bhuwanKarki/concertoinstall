require 'test_helper'

class Frontend::ContentsHelperTest < ActionView::TestCase
end
