require 'test_helper'

class Frontend::ScreensHelperTest < ActionView::TestCase
end
