require 'test_helper'

class TemplatesHelperTest < ActionView::TestCase
end
