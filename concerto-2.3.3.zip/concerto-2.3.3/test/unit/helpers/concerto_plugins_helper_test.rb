require 'test_helper'

class ConcertoPluginsHelperTest < ActionView::TestCase
end
