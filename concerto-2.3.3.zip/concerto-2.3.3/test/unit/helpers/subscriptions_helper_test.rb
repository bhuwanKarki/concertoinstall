require 'test_helper'

class SubscriptionsHelperTest < ActionView::TestCase
end
