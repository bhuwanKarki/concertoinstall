The concerto-init.d script should be copied to /etc/init.d/concerto and installed with update-rc.d and concerto defaults
invoke-rc.d concerto start
