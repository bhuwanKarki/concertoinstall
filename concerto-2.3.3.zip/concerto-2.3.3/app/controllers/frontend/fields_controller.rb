class Frontend::FieldsController < ApplicationController
  layout false
end
